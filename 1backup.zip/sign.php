<!DOCTYPE html>
<html lang="en">



<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>TRUST US</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/animate.min.css" rel="stylesheet"> 
    <link href="css/lightbox.css" rel="stylesheet"> 
	<link href="css/main.css" rel="stylesheet">
	<link href="css/responsive.css" rel="stylesheet">

    <!--[if lt IE 9]>
	    <script src="js/html5shiv.js"></script>
	    <script src="js/respond.min.js"></script>
    <![endif]-->       
    <link rel="shortcut icon" href="images/Amelia_Trust_Logo.ico">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="images/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="images/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="images/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="images/ico/apple-touch-icon-57-precomposed.png">
</head><!--/head-->

<body>
	<header id="header">      
        
        <div class="navbar navbar-inverse" role="banner">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>

                    <a class="navbar-brand" href="http://karthikraja-001-site1.btempurl.com/">
                    	<h1><span class="glyphicon glyphicon-tree-deciduous">TRUST US</span></h1>
                    </a>
                    
                </div>
                <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav navbar-right">
                        <li class="active"><a href="http://karthikraja-001-site1.btempurl.com/"><span class="glyphicon glyphicon-home"><b> Home</b></span></a></li>
                            <ul role="menu" class="sub-menu">
                                
                            </ul>
                        </li>              
						<li><a href="http://karthikraja-001-site1.btempurl.com/user.html"><span class="glyphicon glyphicon-user"><b> USER LOGIN</b></span></i></a>
                        
						<li><a href="http://karthikraja-001-site1.btempurl.com/entry.php"><span class="glyphicon glyphicon-blood"><b>BLOODDONATION</b></i></a>

                        <li><a href="http://karthikraja-001-site1.btempurl.com/chatbox/index.php"><span class="glyphicon glyphicon-plus-sign"><b> DOCTOR</b></span></i></a>
						
						<li><a href="http://karthikraja-001-site1.btempurl.com/ince.php"><span class="glyphicon glyphicon-dangor"><b> INSURANCE</b></i></a>
						
						<li><a href=""><span class="glyphicon glyphicon-king"><b> POLICE</b></i></a>
						
						<li><a href=""><span class="glyphicon glyphicon-globe"><b> ADMIN</b></i></a>
						
					</ul>
                </div>
                <div class="search">
                    <form role="form">
                        <i class="fa fa-search"></i>
                        <div class="field-toggle">
                            <input type="text" class="search-form" autocomplete="on" placeholder="Search">
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </header>
    <!--/#header-->





     <div class="row" align="center">
	
	     <div class="navbar">
    <div class="navbar-inner">
    <center><a class="brand" href="#"><i class="icon-group icon-large"></i>&nbsp;<b>Sign Up</b></a></center>
    </div>
    </div>
	
<div id="body">
	<form action="up.php" method="post" enctype="multipart/form-data" >
<p>
	<div class="control-group">
    <div class="controls">
    <b>User Name*</b>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp;<input type="text" class="span4" name="username" id="inputEmail" placeholder="username" required style="width: 174px;">
    </div>
    </div></p>
	  
	  <p><div class="control-group">
    
    <div class="controls">
    <b>Password*</b>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<input type="password" class="span4" name="password" id="inputEmail" placeholder="password" required style="width: 174px;">
    </div>
    </div>
	</p>
    
   
	
	<p><div class="control-group">
    <div class="controls">
   <b>First Name*</b>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp <input type="text" class="span4" name="firstname" id="inputfirstname" placeholder="firstname" required style="width: 174px;">
    </div>
    </div>
	</p>
	
	<p><div class="control-group">
    <div class="controls">
   <b>Last Name*</b>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp <input type="text" class="span4" name="lastname" id="inputlatname" placeholder="lastname" required style="width: 174px;">
    </div>
    </div>
	</p>
	 
<br/>
<div align="center">
&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<button type="btn-upload" name="btn-upload" class="btn success"><i class="icon-save icon-large"></i>Sign Up</button>
</div>


	
	
	</form>
</div>
    <script type="text/javascript" src="js/jquery.js"></script>
    <script type="text/javascript" src="js/bootstrap.min.js"></script>
    <script type="text/javascript" src="js/lightbox.min.js"></script>
    <script type="text/javascript" src="js/wow.min.js"></script>
    <script type="text/javascript" src="js/main.js"></script>  
</body>
</html>
