<?php
session_start();
session_destroy();
header('location:http://karthikraja-001-site1.btempurl.com/index.html');
?>