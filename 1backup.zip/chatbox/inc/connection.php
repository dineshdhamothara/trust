<?php
    $dsn = 'mysql:host=MYSQL5016.Smarterasp.net;dbname=db_9f9b00_trust';
    $username = '9f9b00_trust';
    $password ='18rockdinu';

    try {
        $con = new PDO($dsn, $username, $password);
    } catch (PDOException $e) {
        $error_message = $e->getMessage();
        include('../errors/err.php');
        exit();
    }
?>


