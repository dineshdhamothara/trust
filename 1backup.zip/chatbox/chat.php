<!DOCTYPE html>
<html >
  <head>
    <meta charset="UTF-8">
    <title>Angular/Bootstrap Chat</title>
    <script src="http://s.codepen.io/assets/libs/modernizr.js" type="text/javascript"></script>


    
    <link rel="stylesheet" href="css/normalize.css">

    <link rel='stylesheet prefetch' href='http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css'>

        <link rel="stylesheet" href="css/style.css">

    <script src="inc/js/jquery.js"></script>
    
    
  </head>
<?php
	if(!isset($_SESSION)) 
	{ 
		session_start(); 
		include('inc/connection.php');
		$username = $_SESSION['user'];
	}
?>
  <body>

    <body ng-app="testapp">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        &nbsp;
      </div>
    </div>
    <div class="row">
      <div class="col-md-4"></div>
      <div class="col-md-4">
        <div class="row">
          <div class="col-md-12">

            <div class="panel panel-primary"  ng-controller="ChatController">
              <div class="panel-heading" style="padding:0 0 0 8px;">
                <span class="glyphicon glyphicon-user"></span>
                <h6 class="panel-title" style="display:inline;">WELCOME:<label for="name"><?php echo $username; ?></label></h6>
                <div class="btn-group btn-group-xs pull-right">
                  <button type="button" class="btn btn-primary"><span class="glyphicon glyphicon-lock"></span></button>
                  
                  <button type="button" class="btn btn-primary"><span class="glyphicon glyphicon-remove"></span></button>
                </div>
                <div class="clearfix"></div>
              </div>
              <div class="panel-body" style="padding:0 4px;">
                <div class="row">
                  <div class="col-xs-12" style="max-height:300px;max-width:100%;overflow-y:auto;overflow-x:hidden;">
                    <table class="table table-hover table-condensed" style="">
                      <tr ng-hide="chatMessages.length === 0" ng-repeat="chat in chatMessages | orderBy:origDt | reverse"
                          style="min-width:100%;max-width:100%;width:100%;">
                        <td><img src="{{chat.icon}}" alt="" style="margin-top:8px;"/></td>
                        <td>
                          <h6>{{chat.username}}</h6>
                        </td>
                        <td>
                        <p class="word-wrap:break-word"><small>{{chat.text}}</small></p>
                        </td>
                      </tr>
                      <tr ng-show="chatMessages.length === 0">
                        <td>
                          <input name="user" type="hidden" id="texta" value="<?php echo $username ?>"/>
						  
						  <form name="newMessage" class="newMessage" action="" onsubmit="return false">
						
					
				</form>
                        </td>
                      </tr>
                    </table>
                  </div>
                </div>
              </div>
              <div class="panel-footer">
                <form>
				<table><td><tr>
				<select name="recipient" id="recipient" style="width:270px;">
							<option>--Send Chat To--</option>
								<?php 
									$sql = "SELECT * FROM tbllogin where username!='$username' ORDER BY username";
									$qry = $con->prepare($sql);
									$qry->execute();
									$fetch = $qry->fetchAll();
									foreach ($fetch as $fe):
										$name = $fe['username'];
								?>
									<option title="<?php echo $name; ?>"><?php echo $fe['username']; ?> </option>
								<?php endforeach; ?>
						</select></tr></td></table>
                  <div class="input-group input-group-sm">
                    <span class="input-group-addon">
                      <img src="http://placehold.it/16x16" alt="" />
                    </span>
                    <input type="text" class="form-control" ng-model="newChatMsg" placeholder="..."/>
                    <span class="input-group-btn">
                      <button class="btn btn-primary" type="submit" ng-click="addChat()"  value="Send" id="johnlei">Send</button>
                    </span>
                  </div>
                </form>
              </div>
            </div>


          </div>
        </div>
      </div>
      <div class="col-md-4"></div>
    </div>
  </div>
</body>
    <script src='http://ajax.googleapis.com/ajax/libs/angularjs/1.3.2/angular.min.js'></script>
<script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.1/jquery.min.js'></script>
<script src='http://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.2.0/js/bootstrap.min.js'></script>

        <script src="js/index.js"></script>

    
    
    
  </body>
</html>
