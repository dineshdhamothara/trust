<html lang="EN">
	<head>
	<?php
	include("header.php");
	?>
		<meta charset="utf-8">
		<style>
			.login_holder {
				padding:3px;
				margin-left:auto;
				margin-right:auto;
				margin-top:10%;
				display:table;
				border:solid 1px #cccccc;
				border-width: thin;
			}
			input[type='submit'] {
				float:center;
			}
		</style>
	</head>
	<body>
	<div class="login_holder">
		<pre><form method="post" action="inc/login.php">
		<label> LOGIN</label>
			<label >Username:</label><input type="text" name="username"/><br/>
			<label >Password:</label><input type="password" name="password"/><br/>
			<input type="submit" value="Submit" name=""/>
		<form></pre><p><a href="sign.php" alt="signup" ><b>Signup</b> </a>
	</div>	
	</body>
</html>