<!DOCTYPE html>
<html lang="en">

<?php
include('header.php');
?>





     <div class="row" align="center">
	
	     <div class="navbar">
    <div class="navbar-inner">
    <center><a class="brand" href="#"><i class="icon-group icon-large"></i>&nbsp;<b>Sign Up</b></a></center>
    </div>
    </div>
	
<div id="body">
	<form action="up.php" method="post" enctype="multipart/form-data" >
<p>
	<div class="control-group">
    <div class="controls">
    <b>USer Name*</b>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp;<input type="text" class="span4" name="username" id="inputEmail" placeholder="username" required style="width: 174px;">
    </div>
    </div></p>
	  
	  <p><div class="control-group">
    
    <div class="controls">
    <b>Password*</b>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<input type="password" class="span4" name="password" id="inputEmail" placeholder="password" required style="width: 174px;">
    </div>
    </div>
	</p>
    
   
	
	<p><div class="control-group">
    <div class="controls">
   <b>Full Name*</b>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp <input type="text" class="span4" name="fullname" id="inputfathername" placeholder="fullname" required style="width: 174px;">
    </div>
    </div>
	</p>
	 
<br/>
<div align="center">
&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<button type="btn-upload" name="btn-upload" class="btn success"><i class="icon-save icon-large"></i>Sign Up</button>
</div>


	
	
	</form>
</div>
   
</body>
</html>
