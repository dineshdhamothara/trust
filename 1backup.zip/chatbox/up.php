<?php
$servername = "MYSQL5016.Smarterasp.net";
$username="9f9b00_trust";
$password="18rockdinu";
$dbname = "db_9f9b00_trust";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 


$username = "username";
 $username=$_POST['username'];
	$password=$_POST['password'];
	$fullname=$_POST['fullname'];

$sql = "INSERT INTO tbllogin (username,password,fullname)
VALUES('$username','$password','$fullname')";

if ($conn->query($sql) === TRUE) {
	echo("Successfully Register Thank you....");
	 header('location:index.php');
    } else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>


