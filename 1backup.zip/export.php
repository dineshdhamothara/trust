<table border="1">
    <tr>
    	<th>NO.</th>
		<th>USER NAME</th>
		<th>PASSWORD</th>
		<th>FIRST NAME</th>
		<th>LAST NAME</th>
	</tr>
	<?php
	//connection to mysql
	mysql_connect("localhost", "root", ""); //server , username , password
	mysql_select_db("trust");
	
	//query get data
	$sql = mysql_query("SELECT * FROM user ORDER BY user ASC");
	$no = 1;
	while($data = mysql_fetch_assoc($sql)){
		echo '
		<tr>
			<td>'.$no.'</td>
			<td>'.$data['username'].'</td>
			<td>'.$data['password'].'</td>
			<td>'.$data['firstname'].'</td>
			<td>'.$data['lastname'].'</td>
		</tr>
		';
		$no++;
	}
	?>
</table>


<?php





// The function header by sending raw excel
header("Content-type: application/vnd-ms-excel");
 
// Defines the name of the export file "codelution-export.xls"
header("Content-Disposition: attachment; filename=codelution-export.xls");
 
// Add data table
include 'tab_user.php';
?>