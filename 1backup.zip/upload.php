<?php
include_once 'dbcon.php';
if(isset($_POST['btn-upload']))
{    
    $fn=$_POST['fn'];
	$ln=$_POST['ln'];
	$bloodgroup=$_POST['bloodgroup'];
	$occupation=$_POST['occupation'];
	$age=$_POST['age'];
	$gender=$_POST['gender'];
	$address=$_POST['address'];
	$email=$_POST['email'];
	$c_number=$_POST['c_number'];
	$donatedate=$_POST['donatedate'];
	$file = rand(1000,100000)."-".$_FILES['file']['name'];
    $file_loc = $_FILES['file']['tmp_name'];
	$file_size = $_FILES['file']['size'];
	$file_type = $_FILES['file']['type'];
	$folder="uploads/";
	
	// new file size in KB
	$new_size = 41943040;
	// new file size in KB
	
	// make file name in lower case
	$new_file_name = strtolower($file);
	// make file name in lower case
	
	$final_file=str_replace(' ','-',$new_file_name);
	if(move_uploaded_file($file_loc,$folder.$final_file))
	{
		$sql="INSERT INTO reg_member (firstname,lastname,bloodgroup,occupation,age,gender,address,email,c_number,donatedate,date,file,type,size) VALUES('$fn','$ln','$bloodgroup','$occupation','$age','$gender','$address','$email','$c_number','$donatedate',NOW(),'$final_file','$file_type','$new_size')";
		mysql_query($sql);
		?>
		<script>
		alert('successfully uploaded');
        window.location.href='index.html?success';
        </script>
		<?php
	}
	else
	{
		?>
		<script>
		alert('!Choose valid file');
        window.location.href='index.php?fail';
        </script>
		<?php
	}
}
?>

