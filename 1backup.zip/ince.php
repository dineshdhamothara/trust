<!DOCTYPE html>
<html lang="en">
<head>
<?php 
include('dbcon.php');
?> 

 <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>TRUST US</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/animate.min.css" rel="stylesheet"> 
    <link href="css/lightbox.css" rel="stylesheet"> 
	<link href="css/main.css" rel="stylesheet">
	<link href="css/responsive.css" rel="stylesheet">

    <!--[if lt IE 9]>
	    <script src="js/html5shiv.js"></script>
	    <script src="js/respond.min.js"></script>
    <![endif]-->       
    <link rel="shortcut icon" href="images/Amelia_Trust_Logo.ico">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="images/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="images/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="images/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="images/ico/apple-touch-icon-57-precomposed.png">
</head><!--/head-->

<body>
	<header id="header">      
        
        <div class="navbar navbar-inverse" role="banner">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>

                    <a class="navbar-brand" href="index.html">
                    	<h1><span class="glyphicon glyphicon-tree-deciduous">TRUST US</span></h1>
                    </a>
                    
                </div>
                <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav navbar-right">
                        <li class="active"><a href="index.html"><span class="glyphicon glyphicon-home"><b> Home</b></span></a></li>
                            <ul role="menu" class="sub-menu">
                                
                            </ul>
                        </li>              
						<li><a href="user.html"><span class="glyphicon glyphicon-user"><b> USER LOGIN</b></span></i></a>
                        
						<li><a href="entry.php"><span class="glyphicon glyphicon-blood"><b>BLOODDONATION</b></i></a>

                        <li><a href="chatbox/index.php"><span class="glyphicon glyphicon-plus-sign"><b> DOCTOR</b></span></i></a>
						
						<li><a href="ince.php"><span class="glyphicon glyphicon-dangor"><b> INSURANCE</b></i></a>
						
						<li><a href=""><span class="glyphicon glyphicon-king"><b> POLICE</b></i></a>
						
						<li><a href=""><span class="glyphicon glyphicon-globe"><b> ADMIN</b></i></a>
						
					</ul>
                </div>
                <div class="search">
                    <form role="form">
                        <i class="fa fa-search"></i>
                        <div class="field-toggle">
                            <input type="text" class="search-form" autocomplete="on" placeholder="Search">
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </header>
    <!--/#header-->

    <section id="home-slider" align="center">
        <div class="row">
		 <div class="navbar">
    <div class="navbar-inner">
    <center><a class="brand" href="#"><i class="icon-group icon-large"></i>&nbsp;<b>USER Vechile</b></a></center>
    </div>
    </div>
		
	
    <div class="span3">
<div id="body">
	<form action="upload1.php" method="post" enctype="multipart/form-data" class="form-horizontal">

	<div class="control-group">
    <label class="control-label" for="inputFirstname"></label>
    <div class="controls">
    <b>Vehicle Type</b>&nbsp&nbsp&nbsp&nbsp<select input type="text" class="span4" name="vt" id="inputEmail" placeholder="FirstName" required style="
    width: 172px;
">
    <option></option>
	<option>Two Wheeler</option>
	<option>Four Wheeler</option>
	</select>
	</div>
    </div>
	  <div class="control-group">
    <label class="control-label" for="inputLastname"></label>
    <div class="controls">
    <b>Manufacturer</b>&nbsp&nbsp<input type="text" class="span4" name="man" id="inputEmail" placeholder="Manufacturer" required style="width: 174px;">
    </div>
    </div>
	
	<div class="control-group">
    <label class="control-label" for="inputLastname"></label>
    <div class="controls">
    <b>Model</b>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<input type="text" class="span4" name="model"  placeholder="Model" style="width: 174px;" required>
    </div>
    </div>
	
	<div class="control-group">
    <label class="control-label" for="inputfathername"></label>
    <div class="controls">
    <b>Color</b>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<input type="text" class="span4" name="color" placeholder="color" style="width: 174px;" required>
    </div>
    </div>
	
	<div class="control-group">
    <label class="control-label" for="inputmothername"></label>
    <div class="controls">
    <b>Year</b>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<select class="span4" id="year" name="year"  placeholder="Year" style="width: 174px;" required>
         <!--Script for year-->     
       <script>
  var myDate = new Date();
  var year = myDate.getFullYear();
  for(var i = 1900; i < year+1; i++){
	  document.write('<option value="'+i+'">'+i+'</option>');
  }
  </script>         
	</select>
	</div>
    </div>
	 
	 <div class="control-group">
    <label class="control-label" for="inputEmail"></label>
    <div class="controls">
	<b>License Plate</b>&nbsp&nbsp&nbsp;<input type="text" class="span4" name="lp" required style="width: 174px;">

    </div>
    </div>
	<br/>
	
		<div class="navbar">
    <div class="navbar-inner">
    <center><a class="brand" href="#"><i class="icon-group icon-large"></i>&nbsp;<b>DATE AND TIME</b></a></center>
    </div>
    </div>
	
	  <div class="control-group">
    <label class="control-label" for="inputEmail"></label>
    <div class="controls">
    <b>Date</b>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<input type="date" class="span4" name="dt" id="inputpersonEmail" placeholder="Email Address" required style="width: 174px;">
    </div>
    </div>
	
	
	  <div class="control-group">
    <label class="control-label" for="inputEmail"></label>
    <div class="controls">
    <b>Time</b>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp <input type="time" class="span4" name="time" placeholder="Personal Phone Number" required style="width: 174px;">
    </div>
    </div>
	
	<br/>
	<div class="navbar">
    <div class="navbar-inner">
    <center><a class="brand" href="#"><i class="icon-group icon-large"></i>&nbsp;<b>THIRD PARTY</b></a></center>
    </div>
    </div>
	
	  <div class="control-group">
    <label class="control-label" for="inputEmail"></label>
    <div class="controls">
    <b>Driver Name</b>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp <input type="text" class="span4" name="driver"  placeholder="Driver Name" required style="width: 174px;"> 
    </div>
    </div>
	
	  <div class="control-group">
    <label class="control-label" for="inputEmail"></label>
    <div class="controls">
    <b>Driver ID</b>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp <input type="text" class="span4" name="driverid" placeholder="Driver ID" required style="width: 174px;">
    </div>
    </div>
	
	
	  <div class="control-group">
    <label class="control-label" for="inputEmail"></label>
    <div class="controls">
    <b>Address</b>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<textarea rows="4" cols="50" class="span4" name="address1"  placeholder="Address" required style="width: 174px;">  </textarea>
    </div>
    </div>

	<div class="control-group">
    <label class="control-label" for="inputEmail"></label>
    <div class="controls">
    <b>Phone Number</b>&nbsp&nbsp&nbsp&nbsp<input type="text" class="span4" name="phoneno"  placeholder="Phone Number" maxlength="10" required style="width: 174px;">
    </div>
    </div>
	<div class="control-group">
    <label class="control-label" for="inputEmail"></label>
    <div class="controls">
    <b>License Number</b>&nbsp;&nbsp&nbsp<input type="text" class="span4" name="lno" placeholder="License Number" required style="width: 174px;">
    </div>
    </div>
	
	<br/>
	<div class="navbar">
    <div class="navbar-inner">
    <center><a class="brand" href="#"><i class="icon-group icon-large"></i>&nbsp;<b>INSURANCE</b></a></center>
    </div>
    </div>
	
	  <div class="control-group">
    <label class="control-label" for="inputEmail"></label>
    <div class="controls">
    <b>Agency Name</b>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<input type="text" class="span4" name="aname"  placeholder="Agency Name" required style="width: 174px;">
    </div>
    </div>
	
	  <div class="control-group">
    <label class="control-label" for="inputEmail"></label>
    <div class="controls">
    <b>Policy Number</b>&nbsp&nbsp<input type="text" class="span4" name="policyno" placeholder="Policy Number" required style="width: 174px;">
    </div>
    </div>
	
	
	  <div class="control-group">
    <label class="control-label" for="inputEmail"></label>
    <div class="controls">
    <b>Agent Name</b>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<input type="text" class="span4" name="agentname" placeholder="Agent Name" required style="width: 174px;">
    </div>
    </div>

	<div class="control-group">
    <label class="control-label" for="inputEmail"></label>
    <div class="controls">
    <b>Agent Number</b>&nbsp&nbsp&nbsp&nbsp;<input type="text" class="span4" name="agentno" placeholder="Agent Number" required style="width: 174px;">
    </div>
    </div>
	
	
	<br/>
	<div class="navbar">
    <div class="navbar-inner">
    <center><a class="brand" href="#"><i class="icon-group icon-large"></i>&nbsp;<b>Police</b></a></center>
    </div>
    </div>
	
	  <div class="control-group">
    <label class="control-label" for="inputEmail"></label>
    <div class="controls">
    <b>Event Number</b>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<input type="text" class="span4" name="eveno" placeholder="Event Number" required style="width: 174px;">
    </div>
    </div>
	
	  <div class="control-group">
    <label class="control-label" for="inputEmail"></label>
    <div class="controls">
    <b>Case Number</b>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<input type="text" class="span4" name="caseno" placeholder="Case Number" required style="width: 174px;">
    </div>
    </div>
	
	
	  <div class="control-group">
    <label class="control-label" for="inputEmail"></label>
    <div class="controls">
    <b>Unit Name</b>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp;<input type="text" class="span4" name="unitno" placeholder="Unit Name" required style="width: 174px;">
    </div>
    </div>

	<div class="control-group">
    <label class="control-label" for="inputEmail"></label>
    <div class="controls">
    <b>Station Name</b>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<input type="text" class="span4" name="station" placeholder="Station Name" required style="width: 174px;">
    </div>
    </div>
	
	
	<br/>
	<div class="navbar">
    <div class="navbar-inner">
    <center><a class="brand" href="#"><i class="icon-group icon-large"></i>&nbsp;<b>Casualty</b></a></center>
    </div>
    </div>
	
	  <div class="control-group">
    <label class="control-label" for="inputEmail"></label>
    <div class="controls">
    <b>Full Name</b>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp;<input type="text" class="span4" name="c_fn" placeholder="Full Name" required style="width: 174px;">
    </div>
    </div>
	
	  <div class="control-group">
    <label class="control-label" for="inputEmail"></label>
    <div class="controls">
    <b>ID</b>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<input type="text" class="span4" name="c_id" placeholder="ID" required style="width: 174px;">
    </div>
    </div>
	
	
	<div class="control-group">
    <label class="control-label" for="inputEmail"></label>
    <div class="controls">
    <b>Address</b>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<textarea rows="4" cols="50" class="span4" name="c_address"  placeholder="Address" required style="width: 174px;">  </textarea>
    </div>
    </div>

	<div class="control-group">
    <label class="control-label" for="inputEmail"></label>
    <div class="controls">
    <b>Pone Number</b>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp;<input type="text" class="span4" name="c_phoneno" placeholder="Phone Number" maxlength="10" required style="width: 174px;">
    </div>
    </div>
	
	<div class="control-group">
    <label class="control-label" for="inputEmail"></label>
    <div class="controls">
    <b>Age</b>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<input type="text" class="span4" name="c_age" placeholder="Age" required style="width: 174px;">
    </div>
    </div>
	
	<br/>
	<div class="navbar">
    <div class="navbar-inner">
    <center><a class="brand" href="#"><i class="icon-group icon-large"></i>&nbsp;<b>Withness</b></a></center>
    </div>
    </div>
	
	  <div class="control-group">
    <label class="control-label" for="inputEmail"></label>
    <div class="controls">
    <b>FullName</b>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp;<input type="text" class="span4" name="w_fn"  placeholder="Address" required style="width: 174px;">
    </div>
    </div>
	
	  <div class="control-group">
    <label class="control-label" for="inputEmail"></label>
    <div class="controls">
    <b>ID</b>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<input type="text" class="span4" name="w_id" placeholder="Email Address" required style="width: 174px;">
    </div>
    </div>
	
	
	  <div class="control-group">
    <label class="control-label" for="inputEmail"></label>
    <div class="controls">
    <b>Address</b>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<input type="text" class="span4" name="w_address" id="inputPnumber" placeholder="Address" required style="width: 174px;">
    </div>
    </div>

	<div class="control-group">
    <label class="control-label" for="inputEmail"></label>
    <div class="controls">
    <b>Pone Number</b>&nbsp&nbsp&nbsp&nbsp&nbsp<input type="text" class="span4" name="w_phoneno" id="inputpersonEmail" placeholder="Phone Number" maxlength="10" required style="width: 174px;">
    </div>
    </div>
	
	<div class="control-group">
    <label class="control-label" for="inputEmail"></label>
    <div class="controls">
    <b>Age</b>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<input type="text" class="span4" name="w_age" id="inputpersonEmail" placeholder="Age" required style="width: 174px;">
    </div>
    </div>
	
	<div class="control-group">
    <label class="control-label" for="inputEmail"></label>
    <div class="controls">
    <b>Description</b>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<textarea rows="4" cols="50" class="span4" name="w_des"  placeholder="Description" required style="width: 174px;">  </textarea>
    </div>
    </div>
	
	 <div class="control-group" align="center">
    <label class="control-label" for="inputEmail"> Choose The Image File</label>
    
    <input type="file" class="span4" name="file"  style="width: 174px;">
    
    </div>
	
	</div>
	
	
	<div class="control-group" align="center">
    <label class="control-label" for="inputEmail"> </label>
    
    

<div align="center">
<button type="btn-upload" name="btn-upload" class="btn success"><i class="icon-save icon-large"></i>Register</button>
</div></div>
	</form>
</div></div>
    </section>
    <!--/#home-slider-->

    <section id="services">
        
    </section>
      
    
    <!--/#footer-->

    <script type="text/javascript" src="js/jquery.js"></script>
    <script type="text/javascript" src="js/bootstrap.min.js"></script>
    <script type="text/javascript" src="js/lightbox.min.js"></script>
    <script type="text/javascript" src="js/wow.min.js"></script>
    <script type="text/javascript" src="js/main.js"></script>   
</body>
</html>
