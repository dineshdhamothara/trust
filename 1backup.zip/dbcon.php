<?php
$dbhost = "MYSQL5016.Smarterasp.net";
$dbuser = "9f9b00_trust";
$dbpass = "18rockdinu";
$dbname = "db_9f9b00_trust";
mysql_connect($dbhost,$dbuser,$dbpass) or die('cannot connect to the server'); 
mysql_select_db($dbname) or die('database selection problem');
?>




