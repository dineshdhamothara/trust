<?php
include_once 'dbcon.php';
if(isset($_POST['btn-upload']))
{    
    $vt=$_POST['vt'];
	$man=$_POST['man'];
	$model=$_POST['model'];
	$color=$_POST['color'];
	$year=$_POST['year'];
	$lp=$_POST['lp'];
	$dt=$_POST['dt'];
	$time=$_POST['time'];
	$driver=$_POST['driver'];
	$driverid=$_POST['driverid'];
	$address1=$_POST['address1'];
	$phoneno=$_POST['phoneno'];
	$lno=$_POST['lno'];
	$aname=$_POST['aname'];
	$policyno=$_POST['policyno'];
	$agentname=$_POST['agentname'];
	$agentno=$_POST['agentno'];
	$eveno=$_POST['eveno'];
	$caseno=$_POST['caseno'];
	$unitno=$_POST['unitno'];
	$station=$_POST['station'];
	$c_fn=$_POST['c_fn'];
	$c_id=$_POST['c_id'];
	$c_address=$_POST['c_address'];
	$c_phoneno=$_POST['c_phoneno'];
	$c_age=$_POST['c_age'];
	$w_fn=$_POST['w_fn'];
	$w_id=$_POST['w_id'];
	$w_address=$_POST['w_address'];
	$w_phoneno=$_POST['w_phoneno'];
	$w_age=$_POST['w_age'];
	$w_des=$_POST['w_des'];
	$file = rand(1000,100000)."-".$_FILES['file']['name'];
    $file_loc = $_FILES['file']['tmp_name'];
	$file_size = $_FILES['file']['size'];
	$file_type = $_FILES['file']['type'];
	$folder="upload/";
	
	// new file size in KB
	$new_size = 41943040;
	// new file size in KB
	
	// make file name in lower case
	$new_file_name = strtolower($file);
	// make file name in lower case
	
	$final_file=str_replace(' ','-',$new_file_name);
	if(move_uploaded_file($file_loc,$folder.$final_file))
	{
		$sql="INSERT INTO ince  (vt,man,model,color,year,lp,dt,time,driver,driverid,address1,phoneno,lno,aname,policyno,agentname,agentno,eveno,caseno,unitno,station,c_fn,c_id,c_address
		,c_phoneno,c_age,w_fn,w_id,w_address,w_phoneno,w_age,w_des,date,file,type,size) VALUES('$vt','$man','$model','$color','$year','$lp','$dt','$time','$driver','$driverid','$address1','$phoneno','$lno','$aname','$policyno','$agentname','$agentno','$eveno','$caseno','$unitno','$station','$c_fn','$c_id','$c_address','$c_phoneno','$c_age','$w_fn','$w_id','$w_address','$w_phoneno','$w_age','$w_des',NOW(),'$final_file','$file_type','$new_size')";
		mysql_query($sql);
		?>
		<script>
		alert('successfully uploaded');
        window.location.href='index.html?success';
        </script>
		<?php
	}
	else
	{
		?>
		<script>
		alert('!Choose valid file');
        window.location.href='index.php?fail';
        </script>
		<?php
	}
}
?>

