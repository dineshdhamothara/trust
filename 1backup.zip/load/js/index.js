// Cool CSS loader by Keven Martin

setTimeout(function(){
		window.location.href="http://karthikraja-001-site1.btempurl.com/index.html";
	}, 4000);
	
