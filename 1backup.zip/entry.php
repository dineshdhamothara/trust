<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>TRUST US</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/animate.min.css" rel="stylesheet"> 
    <link href="css/lightbox.css" rel="stylesheet"> 
	<link href="css/main.css" rel="stylesheet">
	<link href="css/responsive.css" rel="stylesheet">

    <!--[if lt IE 9]>
	    <script src="js/html5shiv.js"></script>
	    <script src="js/respond.min.js"></script>
    <![endif]-->       
    <link rel="shortcut icon" href="images/Amelia_Trust_Logo.ico">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="images/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="images/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="images/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="images/ico/apple-touch-icon-57-precomposed.png">
</head><!--/head-->

<body>
	<header id="header">      
        
        <div class="navbar navbar-inverse" role="banner">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>

                    <a class="navbar-brand" href="index.html">
                    	<h1><span class="glyphicon glyphicon-tree-deciduous">TRUST US</span></h1>
                    </a>
                    
                </div>
                <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav navbar-right">
                        <li class="active"><a href="index.html"><span class="glyphicon glyphicon-home"><b> Home</b></span></a></li>
                            <ul role="menu" class="sub-menu">
                                
                            </ul>
                        </li>              
						<li><a href="user.html"><span class="glyphicon glyphicon-user"><b> USER LOGIN</b></span></i></a>
                        
						<li><a href="entry.php"><span class="glyphicon glyphicon-blood"><b>BLOODDONATION</b></i></a>

                        <li><a href="chatbox/index.php"><span class="glyphicon glyphicon-plus-sign"><b> DOCTOR</b></span></i></a>
						
						<li><a href="ince.php"><span class="glyphicon glyphicon-dangor"><b> INSURANCE</b></i></a>
						
						<li><a href=""><span class="glyphicon glyphicon-king"><b> POLICE</b></i></a>
						
						<li><a href=""><span class="glyphicon glyphicon-globe"><b> ADMIN</b></i></a>
						
					</ul>
                </div>
                <div class="search">
                    <form role="form">
                        <i class="fa fa-search"></i>
                        <div class="field-toggle">
                            <input type="text" class="search-form" autocomplete="on" placeholder="Search">
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </header>
    <!--/#header-->

<?php
include('dbcon.php');
?>





     <div class="row" align="center">
	
	     <div class="navbar">
    <div class="navbar-inner">
    <center><a class="brand" href="#"><i class="icon-group icon-large"></i>&nbsp;<b>BloodDonners Registeration Form</b></a></center>
    </div>
    </div>
	
<div id="body">
	<form action="upload.php" method="post" enctype="multipart/form-data" >
<p>
	<div class="control-group">
    <div class="controls">
    <b>FirstName*</b>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp;<input type="text" class="span4" name="fn" id="inputEmail" placeholder="FirstName" required style="width: 174px;">
    </div>
    </div></p>
	  
	  <p><div class="control-group">
    
    <div class="controls">
    <b>LastName*</b>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<input type="text" class="span4" name="ln" id="inputEmail" placeholder="LastName" required style="width: 174px;">
    </div>
    </div>
	</p>
    
    <p>
	<b>BloodGroup*</b>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<select class="span4" name="bloodgroup" required style="
    width: 170px;
">
	<option></option>
	<option>A+</option>
	<option>A-</option>
	<option>B+</option>
	<option>B-</option>
	<option>O+</option>
	<option>O-</option>
	<option>AB+</option>
	<option>AB-</option>
	<option>Other</option>
	</select>
    </p>
   
	
	<p><div class="control-group">
    <div class="controls">
   <b>Occupation</b>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp <input type="text" class="span4" name="occupation" id="inputfathername" placeholder="occupation" required style="width: 174px;">
    </div>
    </div>
	</p>
	<p><div class="control-group">
    <div class="controls">
    <b>Age*</b>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<input type="text" class="span4" name="age" id="inputmothername" placeholder="age" required style="width: 174px;">
    </div>
    </div>
	 </p>
	<div class="control-group">
    <div class="controls">
	<b>Gender*</b>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
	<select class="span4" name="gender" required style="width: 170px;">
	<option></option>
	<option>Male</option>
	<option>Female</option>
	</select>
    </div>
    </div> 
	
	  <p><div class="control-group">
  <div class="controls">
    <b>Address*</b>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<input type="text" class="span4" name="address" id="inputAddress" placeholder="Address" required style="width: 174px;">
    </div>
    </div>
	</p>
	 <p> <div class="control-group">
    <div class="controls">
    <b>E-Mail Address*</b>&nbsp&nbsp&nbsp&nbsp<input type="text" class="span4" name="email" id="inputpersonEmail" placeholder="Email Address" required style="width: 174px;">
    </div>
    </div>
	</p>
	
	  <p><div class="control-group">
   <div class="controls">
    <b>Phone Number*</b>&nbsp&nbsp&nbsp&nbsp<input type="text" class="span4" name="c_number" id="inputPnumber" placeholder="Personal Phone Number" required style="width: 174px;">
    </div>
    </div>
 </p>
	 <p><div class="control-group">
    <div class="controls">
   <b>Last DonateDate*</b><input type="date" class="span4" name="donatedate" id="inputDepartment" placeholder="DonateDate" required style="
    height: 24px;
    width: 175px;
">
    </div>
    </div></p></div>
	
	
	<div class="control-group">
   
    <div class="controls">
    <b>Set Your Profile picture</b>*(image file only)<input type="file" name="file" class="btn btn" placeholder="Alternate">
    </div>
    </div>
<br/>
<div align="center">
&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<button type="btn-upload" name="btn-upload" class="btn success"><i class="icon-save icon-large"></i>Register</button>
</div>
	</form>
</div>
   
	
	  <script type="text/javascript" src="page/js/jquery.js"></script>
    <script type="text/javascript" src="page/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="page/js/lightbox.min.js"></script>
    <script type="text/javascript" src="page/js/wow.min.js"></script>
    <script type="text/javascript" src="page/js/main.js"></script>  
	
</div>
</body>
</html>


























